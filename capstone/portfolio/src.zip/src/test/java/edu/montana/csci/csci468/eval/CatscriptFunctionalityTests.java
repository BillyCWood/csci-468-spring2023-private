package edu.montana.csci.csci468.eval;

import edu.montana.csci.csci468.CatscriptTestBase;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CatscriptFunctionalityTests extends CatscriptTestBase {


    @Test
    void fibonacciSequence() {
        assertEquals("89\n", executeProgram("var recursionLevel : int = 1" +
                "function fibonacci(level : int, prevSum : int, currSum : int){" +
                "if(level < 10){"+
                " fibonacci(level + 1, currSum, prevSum + currSum)"+
                "}else{"+
                "print(prevSum + currSum)"+
                "}"+
                "}"+
                "fibonacci(recursionLevel, 0, 1)"));
    }

    @Test
    void stringConcatenationInForLoop() {
        assertEquals("a123\n321a\na123321a\n", executeProgram("var myString1 = \"a\"" +
                "var myString2 = \"a\"" +
                "for( x in [1, 2, 3] ) {\n" +
                "  myString1 = myString1 + x" +
                "}\nprint(myString1)" +
                "for( x in [1, 2, 3] ) {\n" +
                "  myString2 = x + myString2" +
                "}\nprint(myString2)\nprint(myString1 + myString2)"));
    }

    @Test
    void sumSquareDifference() {
        assertEquals("2640\n", executeProgram("var sumOfSquares : int = 0\n" +
                "var squareOfSums : int = 0\n" +
                "for(x in [1,2,3,4,5,6,7,8,9,10]){\n"+
                "var square = x * x\n"+
                "sumOfSquares = sumOfSquares + square\n" +
                "}\n" +
                "for(x in [1,2,3,4,5,6,7,8,9,10]){\n"+
                "squareOfSums = squareOfSums + x\n" +
                "}\n" +
                "squareOfSums = squareOfSums * squareOfSums\n" +
                "print(squareOfSums - sumOfSquares)\n"));
    }

}
